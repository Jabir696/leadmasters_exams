export default function Result({ score }) {
  return (
    <div className="flex flex-col items-center justify-center h-screen bg-gradient-to-br from-purple-100 to-purple-300">
      <div className="bg-white shadow-lg rounded-xl p-8 w-96 text-center">
        <h2 className="text-3xl font-bold text-purple-600 mb-4">Exam Completed</h2>
        <p className="text-lg mb-6">Your Score: <span className="font-bold">{score}</span></p>
        <p className="text-gray-500">Well done! You have completed the test.</p>
      </div>
    </div>
  );
}