import { useEffect, useState, useRef } from "react";

export default function Exam({ token, setScore, setView }) {
  const [questions, setQuestions] = useState([]);
  const [current, setCurrent] = useState(0);
  const [answers, setAnswers] = useState({});
  const [time, setTime] = useState(30 * 60);

  const answersRef = useRef(answers);
  useEffect(() => { answersRef.current = answers; }, [answers]);

  useEffect(() => {
    fetch("http://127.0.0.1:8000/questions", {
      headers: { "Authorization": "Bearer " + token }
    })
      .then(res => res.json())
      .then(data => setQuestions(data.questions || []))
      .catch(() => setQuestions([]));
  }, [token]);

  useEffect(() => {
    const timer = setInterval(() => {
      setTime(t => {
        if (t <= 1) {
          handleSubmit(answersRef.current);
          return 0;
        }
        return t - 1;
      });
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  const handleSubmit = async (finalAnswers = answers) => {
    try {
      const res = await fetch("http://127.0.0.1:8000/submit", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": "Bearer " + token
        },
        body: JSON.stringify({ answers: finalAnswers })
      });
      const data = await res.json();
      setScore(data.score ?? 0);
      setView("result");
    } catch (e) {
      alert("Submit failed. Please try again.");
    }
  };

  if (questions.length === 0) return <div className="text-center p-10 text-lg">Loading questions...</div>;

  const q = questions[current];

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col items-center p-6">
      <div className="bg-white shadow-md rounded-lg p-6 w-full max-w-3xl">
        <div className="flex justify-between mb-4">
          <span className="text-gray-600">Question {current + 1} / {questions.length}</span>
          <span className="font-bold text-red-500">
            Time: {Math.floor(time / 60)}:{String(time % 60).padStart(2, "0")}
          </span>
        </div>

        <h4 className="text-lg font-semibold mb-4">{q.question_text}</h4>

        {["option_a", "option_b", "option_c", "option_d"].map((opt, idx) => {
          const letter = String.fromCharCode(65 + idx);
          return (
            <label
              key={opt}
              className="block border rounded-lg p-3 mb-3 cursor-pointer hover:bg-gray-100"
            >
              <input
                type="radio"
                name={`q_${q.id}`}
                onChange={() => setAnswers({ ...answers, [q.id]: letter })}
                checked={answers[q.id] === letter}
                className="mr-3"
              />
              {q[opt]}
            </label>
          );
        })}

        <div className="mt-6 flex justify-between">
          <button
            disabled={current === 0}
            onClick={() => setCurrent(c => c - 1)}
            className="px-4 py-2 bg-gray-300 rounded disabled:opacity-50"
          >
            Previous
          </button>
          <button
            disabled={current === questions.length - 1}
            onClick={() => setCurrent(c => c + 1)}
            className="px-4 py-2 bg-gray-300 rounded disabled:opacity-50"
          >
            Next
          </button>
          <button
            onClick={() => handleSubmit()}
            className="px-4 py-2 bg-blue-500 text-white rounded hover:bg-blue-600"
          >
            Submit Exam
          </button>
        </div>
      </div>
    </div>
  );
}